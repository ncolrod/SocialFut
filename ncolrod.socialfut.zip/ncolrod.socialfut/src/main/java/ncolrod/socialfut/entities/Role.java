package ncolrod.socialfut.entities;

public enum Role {
    USER,ADMIN
}
